import json
import pandas as pd
import random 
import util.intent_handler as intent_handler
import util.user_data_access as user_score
import util.word_sender as word_sender
from util.responseBuilder import *
with open('./resources/AlexaResponses.json') as json_file:  
    alexaResponses = json.load(json_file)
with open('./resources/additional_response_ans_sounds.json') as json_file:  
    additional_responses = json.load(json_file)
    
dictinoary_df = pd.read_csv('./resources/dictionary.csv')


# --------------- entry point -----------------

def lambda_handler(event, context):
    """ App entry point  """
    print("---Event---")
    print(event)
    print("---End---")
    view = True
    if "Viewport" not in event['context']:
        view = False
    if event['request']['type'] == "LaunchRequest":
        return on_launch(event['request'], event['session'],view)
    elif event['request']['type'] == "IntentRequest":
        return on_intent(event['request'], event['session'],view)
    elif event['request']['type'] == "SessionEndedRequest":
        return on_session_ended()


#------------------On Launch Welcome---------------
def on_launch(request, session,view):
    """ start """
    score = user_score.read_to_S3(session["user"]["userId"])
    score = int(score)
    cardTitle = "Welcome"
    completeWord = ""
    word = word_sender.first_word().split(":")[0]
    meaning = word_sender.first_word().split(":")[1]
    music = additional_responses["welcome_sound"][random.randint(0,len(additional_responses["welcome_sound"])-1)]
    if score == 0:
        speechOutput = '<speak>'+music+alexaResponses['Welcome_first_time']+', so heres the word, '+word+', now tell a word starting with  '+word[-1]+'</speak>'
        text=alexaResponses['WelcomeText']+', so heres the word, '+word+', now tell a word starting with  '+word[-1]
    else:
        speechOutput = '<speak>'+music+alexaResponses['Welcome']+', so heres the word, '+word+', now tell a word starting with  '+word[-1]+'</speak>'
        text=alexaResponses['WelcomeText']+', so heres the word, '+word+', now tell a word starting with  '+word[-1]
    attributes = { 
        'MESSAGE':speechOutput,
        'TEXT':text,
        'CONTEXT':"",
        'ANSWERS':"",
        'WORD_Used':[],
        'MEANING':"",
        'POINTS':0,
        'highScore':score,
        'highScoreMessageDone':True
                 }
    attributes["WORD_Used"].append(word)
    attributes["MEANING"] = meaning
    reprompt = speechOutput
    return response(attributes, speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))
#--------------------End of Welcome---------------------

def on_intent(request,session,view):
    if "attributes" not in session:
        return on_launch(request, session,view)
    else:
        intent = request["intent"]["name"]
        print(intent)
        if intent == "not_acceptable":
            return intent_handler._not_acceptable(request,session,view)
        elif intent == "word_ans":
            return intent_handler.acceptable(request,session,view)
        elif intent == "meaning_intent":
            return intent_handler._tell_meaning(request,session,view)
        elif intent == "spelling_intent":
            return intent_handler._tell_spelling(request,session,view)
        elif intent == "high_score_intent":
            return intent_handler._high_score(request,session,view)
        elif intent == "score_intent":
            return intent_handler._score(request,session,view)
        elif intent == "AMAZON.RepeatIntent":
            return intent_handler._repeat_message(request,session,view)
        elif intent == "AMAZON.FallbackIntent":
            return intent_handler.fallback_not_acceptable(request,session,view)
        elif intent == "AMAZON.CancelIntent":
            return intent_handler._stop(request,session,view)
        elif intent == "AMAZON.HelpIntent":
            return intent_handler._help(request,session,view)
        elif intent == "AMAZON.StopIntent":
            return intent_handler._stop(request,session,view)
        else:
            return intent_handler._not_acceptable(request,session,view)
    
    
def on_session_ended():
    """ called on session end  """
    #print(on_session_ended)