import random
import json
with open('./resources/apl_files/main.json') as json_file:  
    main = json.load(json_file)
with open('./resources/apl_files/data.json') as json_file:  
    data = json.load(json_file)


image={
    "charImage":[
        "https://s3.amazonaws.com/user-data-bucket-csv/images/wt1.png",
        "https://s3.amazonaws.com/user-data-bucket-csv/images/wt2.png",
        "https://s3.amazonaws.com/user-data-bucket-csv/images/wt3.png",
        "https://s3.amazonaws.com/user-data-bucket-csv/images/wt4.png",
        "https://s3.amazonaws.com/user-data-bucket-csv/images/wt5.png",
        "https://s3.amazonaws.com/user-data-bucket-csv/images/wt6.png",
    ],
    "bgImage":"https://s3.amazonaws.com/user-data-bucket-csv/images/bg+new+(1).png"
}    


def speech_response_prompt_card(title, output, text, reprompt, endsession,view,word):
    """  create a simple json response with a card  """
    print("viewport----",view)
    response_json =  {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': output
        },
         'card': {
            'type': 'Simple',
            'title': title,
            'content': text
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'SSML',
                'ssml': reprompt
            }
        },
        'shouldEndSession': endsession
    }
    if(view):
        charImage = image["charImage"][random.randint(0,len(image["charImage"])-1)]
        data["bodyTemplate3Data"]["title"] = "Word Warrior"
        data["bodyTemplate3Data"]["image"]["sources"][0]["url"] = charImage
        data["bodyTemplate3Data"]["image"]["sources"][1]["url"] = charImage
        data["bodyTemplate3Data"]["textContent"]["title"]["text"] = title
        data["bodyTemplate3Data"]["textContent"]["primaryText"]["text"] = text
        response_json['directives'] =[{
        'type': 'Alexa.Presentation.APL.RenderDocument',
        'version': '1.0',
        'document': main,
        'datasources': data,
       }]
        '''
        response_json['directives'] = [{
            'type': 'Display.RenderTemplate',
            'template': {
                'type': 'BodyTemplate2',
                'token': 'A2079',
                'backButton': 'HIDDEN',
                'backgroundImage': {
                    'contentDescription': 'Textured grey background',
                    'sources': [{
                        'url': image["bgImage"]
                    }]
                },
                'title': title,
                'image': {
                    'contentDescription': '',
                    'sources': [{
                        'url': charImage
                    }]
                },
                'textContent': {
                    'primaryText': {
                        'text': text,
                        'type': 'PlainText'
                    },
                    'secondaryText': {
                        'text': '',
                        'type': 'PlainText'
                    },
                    'tertiaryText': {
                        'text': '',
                        'type': 'PlainText'
                    }
                }
            }
        }]
        '''
        print(response_json)
    return response_json
    
    
def response(attributes, speech_response):
    """ create a simple json response """
    return {
        'version': '1.0',
        'sessionAttributes': attributes,
        'response': speech_response
    }