import boto3
import json
import io
import pandas as pd
import os

key_id = os.environ['aws_access_key_id']
secret_key = os.environ['aws_secret_access_key']

def read_to_S3(user_id):
    print("reached to user data function")
    highScore = None
    s3 = boto3.client('s3', aws_access_key_id=key_id, aws_secret_access_key=secret_key)
    obj = s3.get_object(Bucket='user-data-bucket-csv', Key='User_data.csv')
    df = pd.read_csv(io.BytesIO(obj['Body'].read()))
    df.set_index("User_ID", inplace=True)
    try:
        highScore = df["User_score"].loc[user_id]
    except:
        data_new = {
            "User_ID":[user_id],
            "User_name":["GumNam"],
            "User_score":[0]
            }
        df_new = pd.DataFrame(data_new)
        df_new.set_index("User_ID", inplace=True)
        df = df.append(df_new)
        #print(df)
        csv_buffer = io.StringIO()
        # Write dataframe to buffer
        df.to_csv(csv_buffer, sep=",", index=True)
        # Write buffer to S3 object
        s3_resource = boto3.resource("s3")
        s3_resource.Object('user-data-bucket-csv','User_data.csv').put(Body=csv_buffer.getvalue())
        highScore = 0
    return highScore
    
def write_to_S3(user_id,count):
    highScore = None
    s3 = boto3.client('s3', aws_access_key_id=key_id, aws_secret_access_key=secret_key)
    obj = s3.get_object(Bucket='user-data-bucket-csv', Key='User_data.csv')
    df = pd.read_csv(io.BytesIO(obj['Body'].read()))
    df.set_index("User_ID", inplace=True)
    df['User_score'].loc[user_id] = count
    print(df)
    csv_buffer = io.StringIO()
    # Write dataframe to bufferAnn#8055KAmmn
    df.to_csv(csv_buffer, sep=",", index=True)
    # Write buffer to S3 object
    s3_resource = boto3.resource("s3")
    s3_resource.Object('user-data-bucket-csv','User_data.csv').put(Body=csv_buffer.getvalue())
    highScore = 0
    return highScore