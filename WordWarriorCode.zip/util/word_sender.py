import pandas as pd
import random 

dictinoary_df = pd.read_csv('./resources/dictionary.csv')

def first_word():
    while True:
        random_number = random.randint(0,len(dictinoary_df))
        word = dictinoary_df["Word"].iloc[random_number]
        if len(word) > 3:
            meaning = dictinoary_df["Meaning"].iloc[random_number]
            word = word+":"+meaning
            break
    return word

def followup_word(user_input,used_words):
    last_char = user_input[-1]
    word_set = dictinoary_df[dictinoary_df["Word"].str.lower().str.startswith(last_char)]
    while True:
        random_number = random.randint(0,len(word_set)-1)
        word = word_set["Word"].iloc[random_number]
        meaning = word_set["Meaning"].iloc[random_number]
        if word not in used_words and len(word) > 3:
            #used_words.append(word)
            word = word+":"+meaning
            break
    print(word)
    return word