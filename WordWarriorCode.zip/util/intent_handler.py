import util.responseBuilder as responseBuilder
import util.user_data_access as user_score
import util.word_sender as word_sender
import json
import random
with open('./resources/AlexaResponses.json') as json_file:  
    alexaResponses = json.load(json_file)
with open('resources/additional_response_ans_sounds.json') as json_file:  
    additional_responses = json.load(json_file)

def _not_acceptable(request,session,view):
    cardTitle = "Confusied"
    completeWord = ""
    not_slot = ["not_ans_random","not_ans_ninteen","not_ans_eighteen","not_ans_seventeen","not_ans_sixteen","not_ans_fifteen","not_ans_long","not_ans_forteen","not_ans_thirteen","not_ans_twelev","not_ans_eleven","not_ans_ten","not_ans_nine","not_ans_eight","not_ans_number","not_ans_seven","not_ans_six","not_ans_five","not_ans_four","not_ans_three","not_ans_two","not_ans_one","not_ans"]
    for val in not_slot:
        try:
            if "value" in request["intent"]["slots"][val]:
                user_input = request["intent"]["slots"][val]["value"]
        except:
            continue
    if user_input.lower() == 'stop' or user_input.lower() == 'exit'or user_input.lower() == 'cancel':
        return _stop(request,session,view)
    if user_input.lower() == 'meaning':
        return _tell_meaning(request,session,view)
    if user_input.lower() == 'spelling':
        return _tell_spelling(request,session,view)
    if user_input.lower() == 'help':
        return _help(request,session,view)
    if user_input.lower() == 'score':
        return _score(request,session,view)
    if user_input.lower() == 'high score':
        return _high_score(request,session,view)
    if user_input.lower() == 'repeat':
        return _repeat_message(request,session,view)
    speechOutput = '<speak>'+ additional_responses["error"][random.randint(0,len(additional_responses["error"])-1)]+', now tell a word starting with '+session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text="I don't think, I can allow this word please tell another word"
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))


def acceptable(request,session,view):
    speechOutput = ""
    completeWord = ""
    cardTitle = "Great Response"
    if "value" in request["intent"]["slots"]["ans_two"]:
        user_input = request["intent"]["slots"]["ans_two"]["value"]
    elif "value" in request["intent"]["slots"]["ans_one"]:
        user_input = request["intent"]["slots"]["ans_one"]["value"]
    elif "value" in request["intent"]["slots"]["ans_three"]:
        user_input = request["intent"]["slots"]["ans_three"]["value"]
    else:
        user_input = request["intent"]["slots"]["ans"]["value"]
    if user_input.lower() == 'stop' or user_input.lower() == 'exit'or user_input.lower() == 'cancel':
        return _stop(request,session,view)
    if user_input.lower() == 'meaning':
        return _tell_meaning(request,session,view)
    if user_input.lower() == 'spelling':
        return _tell_spelling(request,session,view)
    if user_input.lower() == 'help':
        return _help(request,session,view)
    if user_input.lower() == 'score':
        return _score(request,session,view)
    if user_input.lower() == 'high score':
        return _high_score(request,session,view)
    if user_input.lower() == 'repeat':
        return _repeat_message(request,session,view)

    if user_input in session["attributes"]["WORD_Used"]:
        speechOutput = '<speak> This word is already used, tell another word, now tell a word starting with '+session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
        text="This word is already used, tell another word "        
    else:
        used_words = session["attributes"]["WORD_Used"]
        if user_input[0].lower() != used_words[-1][-1].lower():
            speechOutput = '<speak> this word doesnt start with '+used_words[-1][-1].lower()+'</speak>'
            text = 'This word doesnt start with '+used_words[-1][-1].lower()
        else:
            used_words.append(user_input)
            points = session["attributes"]["POINTS"]
            points = points+1
            session["attributes"]["POINTS"] = points
            highScore = session["attributes"]["highScore"]
            if points > highScore and session["attributes"]["highScoreMessageDone"]:
                session["attributes"]["highScoreMessageDone"] = False
                cheer = additional_responses["audio_cheer"][random.randint(0,len(additional_responses["audio_cheer"])-1)]
                firstword = additional_responses["high_score"][random.randint(0,len(additional_responses["high_score"])-1)]
                speechOutput = cheer+firstword+" you hit new high score "
                user_score.write_to_S3(session["user"]["userId"],points)
            word_temp = word_sender.followup_word(user_input,used_words)
            word_temp = word_temp.split(":")
            print(word_temp)
            word = word_temp[0]
            meaning = word_temp[1]
            speechOutput = '<speak>'+speechOutput+ 'new word is,<break time="1s"/> '+word+', now tell a word starting with '+ word[-1]+'</speak>'
            text = 'new word is, '+word+', now tell a word starting with '+ word[-1]
            completeWord = "-"
            session["attributes"]["WORD_Used"].append(word)
            session["attributes"]["MEANING"] = meaning
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

def _tell_meaning(request,session,view):
    cardTitle = "Meaning"
    completeWord = ""
    speechOutput = '<speak>'+ 'Meaning of '+session["attributes"]["WORD_Used"][-1]+' is,<break time="1s"/> '+ session["attributes"]["MEANING"]+',<break time="1s"/> now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text='Meaning of '+session["attributes"]["WORD_Used"][-1]+' is '+ session["attributes"]["MEANING"]+', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

def _repeat_message(request,session,view):
    cardTitle = "Repeat"
    completeWord = ""
    speechOutput = session["attributes"]["MESSAGE"]
    text = session["attributes"]["TEXT"]
    reprompt = speechOutput
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

def _help(request,session,view):
    cardTitle = "Help"
    completeWord = ""
    speechOutput = '<speak>'+ alexaResponses['Help'] +", your word is, "+ session["attributes"]["WORD_Used"][-1]+', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text = alexaResponses['HelpText']+', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

def _stop(request,session,view):
    cardTitle = "Good Bye"
    completeWord = ""
    speechOutput = '<speak>'+ 'Good bye and dont forget to come back' +'</speak>'
    text='Good bye'
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    if session["attributes"]["POINTS"] > session["attributes"]["highScore"]:
        user_score.write_to_S3(session["user"]["userId"],session["attributes"]["POINTS"])        
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, True,view,completeWord))

def _tell_spelling(request,session,view):
    cardTitle = "Spelling"
    completeWord = ""
    speechOutput = '<speak><say-as interpret-as="spell-out">'+ session["attributes"]["WORD_Used"][-1] +'</say-as>'+', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text = session["attributes"]["WORD_Used"][-1]
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

def _high_score(request,session,view):
    cardTitle = "High Score"
    completeWord = ""
    speechOutput = '<speak>Your highest score from previous games is, '+ str(session["attributes"]["highScore"]) +', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text='High-Score : '+str(session["attributes"]["highScore"])
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))


def _score(request,session,view):
    cardTitle = "Score"
    completeWord = ""
    speechOutput = '<speak>Your current score is, '+ str(session["attributes"]["POINTS"])+', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text='score : ' + str(session["attributes"]["POINTS"])
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

def fallback_not_acceptable(request,session,view):
    cardTitle = "Confusied"
    completeWord = ""
    speechOutput = '<speak>'+ additional_responses["error"][random.randint(0,len(additional_responses["error"])-1)]+', now tell a word starting with '+ session["attributes"]["WORD_Used"][-1][-1]+'</speak>'
    text="I don't think, I can allow this word please tell another word"
    reprompt = speechOutput
    session["attributes"]["MESSAGE"] = speechOutput
    session["attributes"]["TEXT"] = text
    attributes = session["attributes"]
    return responseBuilder.response(attributes, responseBuilder.speech_response_prompt_card(cardTitle,speechOutput,text,reprompt, False,view,completeWord))

